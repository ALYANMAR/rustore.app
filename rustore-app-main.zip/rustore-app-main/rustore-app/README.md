Видео с демонстрацией функциональности:
https://cloud.mail.ru/public/Sh4p/xDUWg8UEs
